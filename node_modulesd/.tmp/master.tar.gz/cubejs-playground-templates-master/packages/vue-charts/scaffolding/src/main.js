import vuetify from './plugins/vuetify';

new Vue({
  vuetify,
}).$mount('#app');
