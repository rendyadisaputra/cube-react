module.exports = {
  transpileDependencies: ['vuetify'],
  css: {
    extract: false,
  },
};
