const { TemplatePackage } = require('@cubejs-templates/core');

class ReactChartingLibraryTemplate extends TemplatePackage {}

module.exports = (context) => new ReactChartingLibraryTemplate(context);
