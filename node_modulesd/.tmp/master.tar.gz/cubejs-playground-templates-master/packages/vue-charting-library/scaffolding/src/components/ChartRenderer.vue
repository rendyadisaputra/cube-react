<script>
import Vue from 'vue';
</script>
